import { useEffect, useRef, useState } from 'react';
import { Chart, lineGrad } from '../../utils/chartHelpers.js';
import { gridColor, floats, depths, tempVals, salVals } from '../../data/oceanData.js';

function useChart(type, data, options) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const chart = new Chart(canvasRef.current, { type, data, options });
    return () => chart.destroy();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return canvasRef;
}

function TempDepthChart() {
  const ref = useChart(
    'line',
    { labels: depths, datasets: [{ data: tempVals, borderColor: '#ff6b4a', backgroundColor: (c) => lineGrad(c.chart.ctx, '#ff6b4a'), fill: true, tension: 0.4, pointRadius: 2, pointBackgroundColor: '#ff6b4a' }] },
    { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { y: { reverse: true, title: { display: true, text: 'Depth (dbar)', color: '#7d96a8' }, grid: { color: gridColor } }, x: { title: { display: true, text: '°C', color: '#7d96a8' }, grid: { color: gridColor } } } }
  );
  return <canvas ref={ref} height="220"></canvas>;
}

function SalDepthChart() {
  const ref = useChart(
    'line',
    { labels: depths, datasets: [{ data: salVals, borderColor: '#e0b34d', backgroundColor: (c) => lineGrad(c.chart.ctx, '#e0b34d'), fill: true, tension: 0.4, pointRadius: 2, pointBackgroundColor: '#e0b34d' }] },
    { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { y: { reverse: true, title: { display: true, text: 'Depth (dbar)', color: '#7d96a8' }, grid: { color: gridColor } }, x: { title: { display: true, text: 'PSU', color: '#7d96a8' }, grid: { color: gridColor } } } }
  );
  return <canvas ref={ref} height="220"></canvas>;
}

function HistoryCompareChart() {
  const ref = useChart(
    'bar',
    {
      labels: depths,
      datasets: [
        { label: 'Cycle 114 (now)', data: tempVals, backgroundColor: '#ff6b4a99' },
        { label: '10yr baseline', data: tempVals.map((v) => v - 1.1), backgroundColor: '#2dd4bf55' },
      ],
    },
    { plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, padding: 14, font: { size: 10.5 } } } }, scales: { x: { grid: { display: false } }, y: { grid: { color: gridColor } } } }
  );
  return <canvas ref={ref} height="80" style={{ padding: 14 }}></canvas>;
}

export default function ProfilesView() {
  const [activeFloat, setActiveFloat] = useState('2903421');

  return (
    <div className="view" id="view-profiles">
      <div className="view-head">
        <div><div className="view-eyebrow">Depth-resolved readings</div><div className="view-title">Ocean Profiles</div></div>
        <span className="tag cyan">Float WMO {activeFloat} selected</span>
      </div>
      <div className="profile-grid">
        <div className="panel">
          <div className="panel-head"><h3>Nearby Floats</h3></div>
          <div className="float-list">
            {floats.map((f) => (
              <div
                key={f.id}
                className={`float-item${activeFloat === f.id ? ' active' : ''}`}
                onClick={() => setActiveFloat(f.id)}
              >
                <div className="fid">WMO {f.id}</div>
                <div className="floc">{f.loc}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="profile-main">
          <div className="anomaly-banner">
            <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.6"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4M12 17h.01" /></svg>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>Anomalous warming detected at 180 dbar</div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 3 }}>+1.4°C above the 10-year seasonal baseline for this cycle, consistent with a shallow mesoscale eddy. Flagged 2 hours ago.</div>
            </div>
          </div>
          <div className="profile-charts">
            <div className="panel chart-box">
              <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Temperature vs Depth</h3></div>
              <TempDepthChart />
            </div>
            <div className="panel chart-box">
              <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Salinity vs Depth</h3></div>
              <SalDepthChart />
            </div>
          </div>
          <div className="panel">
            <div className="panel-head"><h3>Historical Comparison — Cycle 114 vs 10yr Baseline</h3><span className="tag mute">Same season</span></div>
            <HistoryCompareChart />
          </div>
        </div>
      </div>
    </div>
  );
}
