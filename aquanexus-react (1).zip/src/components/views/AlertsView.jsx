import { alerts } from '../../data/oceanData.js';

const ICONS = {
  spill: <><path d="M3 12s2-8 9-8 9 8 9 8-2 8-9 8-9-8-9-8z" /><circle cx="12" cy="12" r="3" /></>,
  profile: <><path d="M3 3v18h18" /><path d="M7 14c2-4 3-4 5-1s3 3 5-2 3-4 3-4" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v6l4 2" /></>,
  plus: <><path d="M12 2v20M2 12h20" /></>,
};

export default function AlertsView() {
  return (
    <div className="view" id="view-alerts">
      <div className="view-head">
        <div><div className="view-eyebrow">Prioritized by severity</div><div className="view-title">Active Alerts</div></div>
        <span className="tag coral">{alerts.length} open</span>
      </div>
      <div className="alert-list">
        {alerts.map((a, i) => (
          <div className={`alert-card ${a.severity}`} key={i}>
            <div className="alert-icon">
              <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.6">{ICONS[a.icon]}</svg>
            </div>
            <div style={{ flex: 1 }}>
              <div className="alert-title">{a.title}</div>
              <div className="alert-desc">{a.desc}</div>
              <div className="alert-foot">
                {a.tags.map((t) => <span key={t.label} className={`tag ${t.color}`}>{t.label}</span>)}
                {a.meta.map((m) => <span key={m}>{m}</span>)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
