import { useEffect, useRef } from 'react';
import { Chart, lineGrad } from '../../utils/chartHelpers.js';
import { gridColor } from '../../data/oceanData.js';

function useChart(type, data, options) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const chart = new Chart(canvasRef.current, { type, data, options });
    return () => chart.destroy();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return canvasRef;
}

function TempTrendChart() {
  const ref = useChart(
    'line',
    {
      labels: Array.from({ length: 12 }, (_, i) => 'W' + (i + 1)),
      datasets: [{
        label: 'Basin avg SST',
        data: [26.8, 26.9, 27.0, 27.2, 27.1, 27.3, 27.5, 27.4, 27.6, 27.7, 27.6, 27.6],
        borderColor: '#2dd4bf',
        backgroundColor: (c) => lineGrad(c.chart.ctx, '#2dd4bf'),
        fill: true, tension: 0.4, pointRadius: 0, borderWidth: 2,
      }],
    },
    { plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { grid: { color: gridColor } } } }
  );
  return <canvas ref={ref} height="90"></canvas>;
}

function ModuleDonut() {
  const ref = useChart(
    'doughnut',
    {
      labels: ['ARGO', 'Oil Spill', 'Minerals', 'Cables'],
      datasets: [{ data: [52, 21, 14, 13], backgroundColor: ['#2dd4bf', '#ff6b4a', '#e0b34d', '#8b7fd6'], borderColor: '#0e2032', borderWidth: 3 }],
    },
    { plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, padding: 14, font: { size: 10.5 } } } }, cutout: '68%' }
  );
  return <canvas ref={ref} height="90"></canvas>;
}

function SalinityBar() {
  const ref = useChart(
    'bar',
    {
      labels: ['Arabian Sea', 'Bay of Bengal', 'Andaman Sea', 'Equatorial IO'],
      datasets: [
        { label: 'Surface', data: [36.2, 33.1, 33.6, 35.0], backgroundColor: '#2dd4bf99' },
        { label: '200 dbar', data: [35.6, 34.9, 34.7, 35.2], backgroundColor: '#8b7fd699' },
      ],
    },
    { plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, padding: 14, font: { size: 10.5 } } } }, scales: { x: { grid: { display: false } }, y: { grid: { color: gridColor } } } }
  );
  return <canvas ref={ref} height="95"></canvas>;
}

function AnomalyLine() {
  const ref = useChart(
    'line',
    {
      labels: Array.from({ length: 12 }, (_, i) => 'W' + (i + 1)),
      datasets: [{
        data: [2, 3, 1, 4, 2, 3, 5, 4, 6, 5, 7, 7],
        borderColor: '#ff6b4a',
        backgroundColor: (c) => lineGrad(c.chart.ctx, '#ff6b4a'),
        fill: true, tension: 0.35, pointRadius: 2, pointBackgroundColor: '#ff6b4a',
      }],
    },
    { plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { grid: { color: gridColor }, beginAtZero: true } } }
  );
  return <canvas ref={ref} height="95"></canvas>;
}

export default function DashboardView() {
  return (
    <div className="view" id="view-dashboard">
      <div className="view-head">
        <div><div className="view-eyebrow">Fleet-wide telemetry</div><div className="view-title">Ocean Conditions Dashboard</div></div>
        <span className="tag cyan">Updated 09:44 IST</span>
      </div>

      <div className="stat-grid">
        <div className="panel stat-card"><div className="glow" style={{ background: 'var(--cyan)' }}></div><div className="lbl">Avg Sea Surface Temp</div><div className="val">27.6°C</div><div className="delta" style={{ color: 'var(--coral)' }}>▲ 0.3° vs 10yr avg</div></div>
        <div className="panel stat-card"><div className="glow" style={{ background: 'var(--gold)' }}></div><div className="lbl">Avg Salinity</div><div className="val">35.1 <span style={{ fontSize: 14, color: 'var(--text-mute)' }}>PSU</span></div><div className="delta" style={{ color: 'var(--text-mute)' }}>▬ within normal range</div></div>
        <div className="panel stat-card"><div className="glow" style={{ background: 'var(--coral)' }}></div><div className="lbl">Active Anomalies</div><div className="val">7</div><div className="delta" style={{ color: 'var(--coral)' }}>▲ 2 new this week</div></div>
        <div className="panel stat-card"><div className="glow" style={{ background: 'var(--violet)' }}></div><div className="lbl">Floats Reporting</div><div className="val">3,842</div><div className="delta" style={{ color: 'var(--cyan)' }}>98.4% uptime</div></div>
      </div>

      <div className="chart-grid">
        <div className="panel chart-box">
          <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Temperature Trend — Basin Average</h3><span className="tag mute">90 days</span></div>
          <TempTrendChart />
        </div>
        <div className="panel chart-box">
          <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Module Query Share</h3><span className="tag mute">7 days</span></div>
          <ModuleDonut />
        </div>
      </div>
      <div className="chart-grid">
        <div className="panel chart-box">
          <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Salinity vs Pressure — Regional Comparison</h3><span className="tag mute">4 regions</span></div>
          <SalinityBar />
        </div>
        <div className="panel chart-box">
          <div className="panel-head" style={{ border: 'none', padding: '0 0 6px' }}><h3>Anomaly Frequency</h3><span className="tag mute">12 weeks</span></div>
          <AnomalyLine />
        </div>
      </div>
    </div>
  );
}
