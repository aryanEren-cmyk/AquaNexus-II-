import { trailSteps } from '../../data/oceanData.js';

export default function TrailView() {
  return (
    <div className="view" id="view-trail">
      <div className="view-head">
        <div><div className="view-eyebrow">Agent reasoning, fully auditable</div><div className="view-title">Investigation Trail</div></div>
        <span className="tag mute">Query #4471</span>
      </div>
      <div className="panel" style={{ padding: '16px 20px', marginBottom: 20 }}>
        <div style={{ fontSize: 11, color: 'var(--text-mute)', fontFamily: "'JetBrains Mono',monospace", marginBottom: 4 }}>ORIGINAL QUERY</div>
        <div style={{ fontSize: 14 }}>"Is there anything unusual near the Arabian Sea ARGO floats this week, and could it affect the cable routes nearby?"</div>
      </div>
      <div className="trail-full">
        {trailSteps.map((step, i) => (
          <div className="tstep" key={i}>
            <div className="node">{i + 1}</div>
            <div className="panel tcard">
              <div className="thead"><h4>{step.title}</h4><span className={`tag ${step.badge.color}`}>{step.badge.label}</span></div>
              <p>{step.text}</p>
              <div className="tmeta">{step.meta}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
