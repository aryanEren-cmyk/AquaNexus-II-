import { useState, useRef } from 'react';
import TopBar from './components/TopBar.jsx';
import NavRail from './components/NavRail.jsx';
import ChatView from './components/views/ChatView.jsx';
import DashboardView from './components/views/DashboardView.jsx';
import MapView from './components/views/MapView.jsx';
import ProfilesView from './components/views/ProfilesView.jsx';
import AlertsView from './components/views/AlertsView.jsx';
import TrailView from './components/views/TrailView.jsx';
import ResultsView from './components/views/ResultsView.jsx';

export default function App() {
  const [activeView, setActiveView] = useState('chat');
  const mapInvalidateRef = useRef(null);

  function handleNavChange(view) {
    setActiveView(view);
  }

  return (
    <div className="app">
      <TopBar />
      <NavRail activeView={activeView} onChange={handleNavChange} />
      <div className="main">
        <div className={`view${activeView === 'chat' ? ' active' : ''}`} style={{ display: activeView === 'chat' ? 'block' : 'none' }}>
          <ChatView />
        </div>
        <div className={`view${activeView === 'dashboard' ? ' active' : ''}`} style={{ display: activeView === 'dashboard' ? 'block' : 'none' }}>
          <DashboardView />
        </div>
        <div className={`view${activeView === 'map' ? ' active' : ''}`} style={{ display: activeView === 'map' ? 'block' : 'none' }}>
          <MapView active={activeView === 'map'} onNavRegister={(fn) => (mapInvalidateRef.current = fn)} />
        </div>
        <div className={`view${activeView === 'profiles' ? ' active' : ''}`} style={{ display: activeView === 'profiles' ? 'block' : 'none' }}>
          <ProfilesView />
        </div>
        <div className={`view${activeView === 'alerts' ? ' active' : ''}`} style={{ display: activeView === 'alerts' ? 'block' : 'none' }}>
          <AlertsView />
        </div>
        <div className={`view${activeView === 'trail' ? ' active' : ''}`} style={{ display: activeView === 'trail' ? 'block' : 'none' }}>
          <TrailView />
        </div>
        <div className={`view${activeView === 'results' ? ' active' : ''}`} style={{ display: activeView === 'results' ? 'block' : 'none' }}>
          <ResultsView />
        </div>
      </div>
    </div>
  );
}
