import { Chart } from 'chart.js/auto';

Chart.defaults.color = '#7d96a8';
Chart.defaults.font.family = "'JetBrains Mono', monospace";
Chart.defaults.font.size = 10.5;

export function lineGrad(ctx, color) {
  const g = ctx.createLinearGradient(0, 0, 0, 180);
  g.addColorStop(0, color + '55');
  g.addColorStop(1, color + '00');
  return g;
}

export { Chart };
