// Static demo data — mirrors the original static HTML/JS exactly.
// Swap these for real API/agent responses once the backend is connected.

export const gridColor = 'rgba(255,255,255,0.05)';

export const floats = [
  { id: '2903421', loc: '17.2°N, 68.4°E · cycle 114' },
  { id: '2903188', loc: '14.9°N, 66.1°E · cycle 88' },
  { id: '2902977', loc: '19.5°N, 70.2°E · cycle 201' },
  { id: '2903550', loc: '12.1°N, 64.7°E · cycle 42' },
  { id: '2902810', loc: '16.0°N, 72.3°E · cycle 156' },
];

export const depths = [0, 25, 50, 75, 100, 150, 200, 300, 400, 600, 800, 1000];
export const tempVals = [29.1, 28.7, 27.9, 26.2, 23.8, 19.4, 15.1, 11.2, 8.6, 6.1, 4.8, 4.1];
export const salVals = [35.6, 35.7, 35.8, 35.7, 35.5, 35.3, 35.1, 34.9, 34.7, 34.6, 34.6, 34.7];

export const alerts = [
  {
    severity: 'high',
    title: 'Probable oil-spill signature — Gulf of Kutch approach',
    desc: 'Satellite-derived surface signature (2.1 km²) detected 14 km off the Kutch coast, coinciding with elevated shipping traffic. Confidence: 82%.',
    tags: [{ label: 'OIL SPILL', color: 'coral' }],
    meta: ['22.6°N, 69.1°E', 'Detected 41 min ago'],
    icon: 'spill',
  },
  {
    severity: 'med',
    title: 'Subsurface thermal anomaly near cable corridor',
    desc: 'Float 2903421 recorded +1.4°C at 180 dbar, 38 km from the SEA-ME-WE 5 route. Monitoring for eddy drift toward the corridor.',
    tags: [{ label: 'ARGO', color: 'cyan' }, { label: 'CABLES', color: 'violet' }],
    meta: ['17.2°N, 68.4°E', '2 hrs ago'],
    icon: 'profile',
  },
  {
    severity: 'med',
    title: 'Elevated anchor-drag risk over mineral zone MZ-14',
    desc: 'Shipping density up 34% week-over-week over a nodule-rich seabed zone; two drag incidents logged in the past 30 days.',
    tags: [{ label: 'MINERALS', color: 'gold' }],
    meta: ['15.8°N, 71.0°E', '6 hrs ago'],
    icon: 'clock',
  },
  {
    severity: 'low',
    title: 'Float 2902977 delayed reporting',
    desc: 'No telemetry received for 26 hours, beyond the expected 10-day cycle window. Likely a routine surfacing delay.',
    tags: [{ label: 'ARGO', color: 'cyan' }],
    meta: ['19.5°N, 70.2°E', '1 day ago'],
    icon: 'plus',
  },
];

export const trailSteps = [
  {
    title: 'Intent Parsing',
    badge: { label: '142ms', color: 'mute' },
    text: 'Identified a compound query: (a) anomaly detection request scoped to Arabian Sea region, (b) downstream risk assessment against infrastructure. Extracted entities: region = "Arabian Sea", timeframe = "this week", asset_type = "submarine cable".',
    meta: 'agent.nlu → intent=anomaly_check+risk_assess',
  },
  {
    title: 'Module Selection',
    badge: { label: 'ARGO', color: 'cyan' },
    text: 'Routed to the ARGO module to pull recent profile cycles for floats within the Arabian Sea bounding box, ranked by recency and anomaly score.',
    meta: 'router.select_module → ARGO (confidence 0.94)',
  },
  {
    title: 'Data Retrieval',
    badge: { label: '318ms', color: 'mute' },
    text: 'Fetched last 4 cycles for float WMO 2903421 from NetCDF store; computed deviation against the 10-year seasonal baseline at matching pressure levels.',
    meta: 'argo.get_profile(float=2903421, cycles=4) → +1.4°C @ 180dbar',
  },
  {
    title: 'Cross-Module Correlation',
    badge: { label: 'CABLES', color: 'violet' },
    text: 'Engaged the Cables module to compute the geodesic distance between the anomaly location and the nearest known cable geometry (SEA-ME-WE 5).',
    meta: 'cables.nearest_route(lat=17.2, lon=68.4) → 38.2 km, segment 14',
  },
  {
    title: 'Risk Synthesis',
    badge: { label: 'MEDIUM', color: 'gold' },
    text: 'Combined thermal stress magnitude, distance-to-asset, and recent seismic/shipping context into a composite risk score. Result: medium priority — monitor, no immediate action required.',
    meta: 'agent.synthesize_risk → score=0.47 (medium)',
  },
  {
    title: 'Response Generation',
    badge: { label: '96ms', color: 'mute' },
    text: 'Composed a natural-language summary citing the specific float, magnitude, and distance, and logged a medium-severity alert for continued monitoring.',
    meta: 'agent.respond → alert_created=true',
  },
];

export const resultsRows = [
  { id: '2903421', module: 'ARGO', moduleColor: 'cyan', loc: '17.2°N, 68.4°E', param: 'Temp @ 180dbar', value: '29.1°C', deviation: '+1.4°C', deviationColor: 'coral', status: 'Anomaly', statusColor: 'gold' },
  { id: '2903188', module: 'ARGO', moduleColor: 'cyan', loc: '14.9°N, 66.1°E', param: 'Salinity @ 50dbar', value: '35.4 PSU', deviation: '+0.1', deviationColor: null, status: 'Nominal', statusColor: 'mute' },
  { id: 'OS-1182', module: 'Oil Spill', moduleColor: 'coral', loc: '22.6°N, 69.1°E', param: 'Surface area', value: '2.1 km²', deviation: '—', deviationColor: null, status: 'Active', statusColor: 'coral' },
  { id: 'MZ-14', module: 'Minerals', moduleColor: 'gold', loc: '15.8°N, 71.0°E', param: 'Nodule density', value: '8.4 kg/m²', deviation: '—', deviationColor: null, status: 'Confirmed', statusColor: 'mute' },
  { id: 'SMW5-14', module: 'Cables', moduleColor: 'violet', loc: '17.5°N, 68.7°E', param: 'Distance to anomaly', value: '38.2 km', deviation: '—', deviationColor: null, status: 'Monitoring', statusColor: 'gold' },
  { id: '2902977', module: 'ARGO', moduleColor: 'cyan', loc: '19.5°N, 70.2°E', param: 'Reporting gap', value: '26 hrs', deviation: '—', deviationColor: null, status: 'Delayed', statusColor: 'mute' },
  { id: '2902810', module: 'ARGO', moduleColor: 'cyan', loc: '16.0°N, 72.3°E', param: 'Pressure @ surface', value: '1013 dbar', deviation: '0.0', deviationColor: null, status: 'Nominal', statusColor: 'mute' },
];
