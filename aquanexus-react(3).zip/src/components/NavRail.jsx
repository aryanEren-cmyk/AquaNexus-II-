const NAV_ITEMS = [
  {
    view: 'chat',
    title: 'Conversational Interface',
    label: 'CHAT',
    path: 'M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z',
  },
  {
    view: 'dashboard',
    title: 'Charts & Dashboard',
    label: 'CHARTS',
    path: 'M3 3v18h18',
    extra: 'M18 17V9M13 17V5M8 17v-4',
  },
  {
    view: 'map',
    title: 'Map',
    label: 'MAP',
    path: 'M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4z',
    extra: 'M8 2v16M16 6v16',
  },
  {
    view: 'profiles',
    title: 'Ocean Profiles',
    label: 'PROFILE',
    path: 'M3 3v18h18',
    extra: 'M7 14c2-4 3-4 5-1s3 3 5-2 3-4 3-4',
  },
  {
    view: 'alerts',
    title: 'Alerts',
    label: 'ALERTS',
    path: 'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z',
    extra: 'M12 9v4M12 17h.01',
    badge: 4,
  },
  {
    view: 'trail',
    title: 'Investigation Trail',
    label: 'TRAIL',
    isTrail: true,
  },
  {
    view: 'results',
    title: 'Structured Results',
    label: 'DATA',
    path: 'M3 9h18M9 21V9',
    isResults: true,
  },
];

export default function NavRail({ activeView, onChange }) {
  return (
    <div className="navrail">
      {NAV_ITEMS.map((item) => (
        <div
          key={item.view}
          className={`navbtn${activeView === item.view ? ' active' : ''}`}
          title={item.title}
          onClick={() => onChange(item.view)}
        >
          <svg viewBox="0 0 24 24">
            {item.isTrail ? (
              <>
                <circle cx="12" cy="5" r="2" />
                <circle cx="5" cy="19" r="2" />
                <circle cx="19" cy="19" r="2" />
                <path d="M12 7v5M12 12l-6 5M12 12l6 5" />
              </>
            ) : item.isResults ? (
              <>
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <path d={item.extra} />
              </>
            ) : (
              <>
                <path d={item.path} />
                {item.extra && <path d={item.extra} />}
              </>
            )}
          </svg>
          <span className="lbl">{item.label}</span>
          {item.badge && <div className="nav-alert-badge">{item.badge}</div>}
        </div>
      ))}
    </div>
  );
}
