import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';

const LAYER_ITEMS = [
  { key: 'argo', label: 'ARGO Floats', color: 'var(--cyan)' },
  { key: 'spill', label: 'Oil Spill Zones', color: 'var(--coral)' },
  { key: 'mineral', label: 'Mineral Deposits', color: 'var(--gold)' },
  { key: 'cable', label: 'Submarine Cables', color: 'var(--violet)' },
];

function markerIcon(color) {
  return L.divIcon({
    className: '',
    html: `<div style="width:14px;height:14px;border-radius:50%;background:${color};border:2px solid #08131f;box-shadow:0 0 10px ${color}"></div>`,
    iconSize: [14, 14],
  });
}

export default function MapView({ active }) {
  const mapElRef = useRef(null);
  const mapRef = useRef(null);
  const layersRef = useRef({});
  const [selection, setSelection] = useState(null);
  const [layerState, setLayerState] = useState({ argo: true, spill: true, mineral: true, cable: true });

  useEffect(() => {
    if (mapRef.current) return; // init once
    const map = L.map(mapElRef.current, { zoomControl: true, attributionControl: false }).setView([17.5, 68.5], 5);
    mapRef.current = map;

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 12 }).addTo(map);

    const layers = {
      argo: L.layerGroup([
        L.marker([17.2, 68.4], { icon: markerIcon('#2dd4bf') }).bindPopup('<b>ARGO WMO 2903421</b><br>Temp anomaly +1.4°C @180dbar'),
        L.marker([14.9, 66.1], { icon: markerIcon('#2dd4bf') }).bindPopup('<b>ARGO WMO 2903188</b><br>Nominal readings'),
        L.marker([19.5, 70.2], { icon: markerIcon('#2dd4bf') }).bindPopup('<b>ARGO WMO 2902977</b><br>Reporting delayed 26h'),
        L.marker([16.0, 72.3], { icon: markerIcon('#2dd4bf') }).bindPopup('<b>ARGO WMO 2902810</b><br>Nominal readings'),
      ]).addTo(map),
      spill: L.layerGroup([
        L.circle([22.6, 69.1], { radius: 15000, color: '#ff6b4a', fillColor: '#ff6b4a', fillOpacity: 0.25 }).bindPopup('<b>Spill signature OS-1182</b><br>2.1 km² · confidence 82%'),
      ]).addTo(map),
      mineral: L.layerGroup([
        L.circle([15.8, 71.0], { radius: 22000, color: '#e0b34d', fillColor: '#e0b34d', fillOpacity: 0.18 }).bindPopup('<b>Mineral zone MZ-14</b><br>Nodule density 8.4 kg/m²'),
      ]).addTo(map),
      cable: L.layerGroup([
        L.polyline([[9, 63], [13, 65], [17.5, 68.7], [21, 71], [24.8, 67]], { color: '#8b7fd6', weight: 2.5, dashArray: '6,5' }).bindPopup('<b>SEA-ME-WE 5</b><br>Segment 14 · monitoring'),
      ]).addTo(map),
    };
    layersRef.current = layers;

    map.on('popupopen', (e) => {
      setSelection(e.popup.getContent());
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (active && mapRef.current) {
      setTimeout(() => mapRef.current.invalidateSize(), 150);
    }
  }, [active]);

  function toggleLayer(key) {
    setLayerState((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      const map = mapRef.current;
      const layer = layersRef.current[key];
      if (map && layer) {
        if (next[key]) map.addLayer(layer);
        else map.removeLayer(layer);
      }
      return next;
    });
  }

  return (
    <div className={`view${active ? ' active' : ''}`} id="view-map">
      <div className="view-head">
        <div><div className="view-eyebrow">Geospatial overlay</div><div className="view-title">Live Ocean Map</div></div>
        <span className="tag cyan">{Object.values(layerState).filter(Boolean).length} layers active</span>
      </div>
      <div className="map-layout">
        <div id="map" ref={mapElRef}></div>
        <div className="layer-panel">
          <div className="panel">
            <div className="panel-head"><h3>Layers</h3></div>
            <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {LAYER_ITEMS.map((item) => (
                <div className="layer-item" key={item.key} onClick={() => toggleLayer(item.key)}>
                  <div className="li-left"><span className="swatch" style={{ background: item.color }}></span>{item.label}</div>
                  <div className={`switch${layerState[item.key] ? ' on' : ''}`}></div>
                </div>
              ))}
            </div>
          </div>
          <div className="panel">
            <div className="panel-head"><h3>Legend</h3></div>
            <div className="map-legend-list">
              <div className="row"><span className="swatch" style={{ background: 'var(--cyan)' }}></span>Nominal float reading</div>
              <div className="row"><span className="swatch" style={{ background: 'var(--coral)' }}></span>Detected spill signature</div>
              <div className="row"><span className="swatch" style={{ background: 'var(--gold)' }}></span>Confirmed mineral zone</div>
              <div className="row"><span className="swatch" style={{ background: 'var(--violet)' }}></span>Active cable route</div>
            </div>
          </div>
          <div className="panel" id="mapDetail">
            <div className="panel-head"><h3>Selection</h3></div>
            {selection ? (
              <div style={{ padding: '14px 16px', fontSize: '12.5px', color: 'var(--text-dim)', lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: selection }} />
            ) : (
              <div style={{ padding: '14px 16px', fontSize: 12, color: 'var(--text-mute)' }}>Click a marker on the map to inspect it here.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
