import { useState } from 'react';
import { resultsRows } from '../../data/oceanData.js';

const FILTERS = ['All modules', 'ARGO', 'Oil Spill', 'Minerals', 'Cables'];

export default function ResultsView({ active }) {
  const [filter, setFilter] = useState('All modules');

  const rows = filter === 'All modules' ? resultsRows : resultsRows.filter((r) => r.module === filter);

  return (
    <div className={`view${active ? ' active' : ''}`} id="view-results">
      <div className="view-head">
        <div><div className="view-eyebrow">Machine-readable output</div><div className="view-title">Structured Results</div></div>
        <span className="tag mute">query_id: 4471</span>
      </div>
      <div className="res-toolbar">
        {FILTERS.map((f) => (
          <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      <div className="panel" style={{ overflowX: 'auto' }}>
        <table className="res">
          <thead>
            <tr><th>ID</th><th>Module</th><th>Location</th><th>Parameter</th><th>Value</th><th>Deviation</th><th>Status</th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id + r.param}>
                <td className="mono">{r.id}</td>
                <td><span className={`tag ${r.moduleColor}`}>{r.module}</span></td>
                <td className="mono">{r.loc}</td>
                <td>{r.param}</td>
                <td className="mono">{r.value}</td>
                <td className="mono" style={r.deviationColor ? { color: `var(--${r.deviationColor})` } : undefined}>{r.deviation}</td>
                <td><span className={`tag ${r.statusColor}`}>{r.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
