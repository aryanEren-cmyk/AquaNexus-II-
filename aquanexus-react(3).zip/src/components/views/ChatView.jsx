import { useEffect, useRef, useState } from 'react';
import { Chart, lineGrad } from '../../utils/chartHelpers.js';
import { gridColor } from '../../data/oceanData.js';

const INITIAL_MESSAGES = [
  { id: 'm1', role: 'agent', text: "Welcome back. I'm tracking live ARGO profiles, oil-spill signatures, mineral zones and cable corridors across the Indian Ocean basin. Ask me anything — try a question about a region, a float ID, or a threat type." },
  { id: 'm2', role: 'user', text: 'Is there anything unusual near the Arabian Sea ARGO floats this week, and could it affect the cable routes nearby?', meta: 'You · 09:41' },
  {
    id: 'm3',
    role: 'agent',
    chips: [{ label: 'ARGO', color: 'cyan' }, { label: 'CABLES', color: 'violet' }],
    text: <>Yes — float <b>WMO 2903421</b> recorded a subsurface warm anomaly (+1.4°C at 180 dbar) over the last 4 cycles, consistent with a shallow eddy. It sits 38 km from the SEA-ME-WE 5 cable corridor. Thermal stress this size is unlikely to affect the cable directly, but it's worth watching — I've raised it as a <b>medium</b> alert.</>,
    chart: 'chatMiniChart',
  },
  { id: 'm4', role: 'user', text: 'Show me the risk breakdown', meta: 'You · 09:43' },
  {
    id: 'm5',
    role: 'agent',
    text: "Here's the combined risk read for that corridor segment — ocean stress is low, but I'm flagging elevated shipping density this week.",
    riskCard: true,
  },
];

const SUGGESTIONS = [
  'Nearest oil-spill signature?',
  'Compare salinity to last year',
  'Mineral zones near float 2903421',
];

function ChatMiniChart() {
  const canvasRef = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    chartRef.current = new Chart(canvasRef.current, {
      type: 'line',
      data: {
        labels: ['Cyc 111', 'Cyc 112', 'Cyc 113', 'Cyc 114'],
        datasets: [
          { data: [27.1, 27.6, 28.3, 29.1], borderColor: '#ff6b4a', backgroundColor: (c) => lineGrad(c.chart.ctx, '#ff6b4a'), fill: true, tension: 0.4, pointRadius: 3, pointBackgroundColor: '#ff6b4a' },
          { data: [27.0, 27.1, 27.3, 27.7], borderColor: '#3a4f5f', borderDash: [3, 3], fill: false, tension: 0.4, pointRadius: 0 },
        ],
      },
      options: { plugins: { legend: { display: false } }, scales: { x: { grid: { color: gridColor } }, y: { grid: { color: gridColor } } } },
    });
    return () => chartRef.current?.destroy();
  }, []);

  return (
    <div className="inline-card">
      <div className="ic-head"><span>WMO 2903421 · Temperature Anomaly</span><span>180 dbar</span></div>
      <canvas ref={canvasRef} height="120"></canvas>
    </div>
  );
}

function RiskCard() {
  return (
    <div className="inline-card">
      <div className="ic-head"><span>Corridor Risk Index</span><span>SEA-ME-WE 5 · seg. 14</span></div>
      <div style={{ padding: '14px' }}>
        <div className="mini-stat"><span className="k">Thermal stress</span><span className="v" style={{ color: 'var(--cyan)' }}>LOW</span></div>
        <div className="mini-stat"><span className="k">Seismic activity (7d)</span><span className="v" style={{ color: 'var(--cyan)' }}>LOW</span></div>
        <div className="mini-stat"><span className="k">Shipping density</span><span className="v" style={{ color: 'var(--gold)' }}>ELEVATED</span></div>
        <div className="mini-stat"><span className="k">Anchor-drag incidents (30d)</span><span className="v">2</span></div>
      </div>
    </div>
  );
}

export default function ChatView({ active }) {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  function sendMsg(text) {
    if (!text) return;
    const userMsg = { id: 'u' + Date.now(), role: 'user', text, meta: 'You · now' };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setTimeout(() => {
      const agentMsg = {
        id: 'a' + Date.now(),
        role: 'agent',
        chips: [{ label: 'ARGO', color: 'cyan' }],
        text: 'Pulling relevant profiles and cross-checking against historical baselines now — this is a frontend preview, so responses here are illustrative. Once connected to the live agent backend, this reply will reflect real ARGO, spill, mineral and cable data.',
      };
      setMessages((prev) => [...prev, agentMsg]);
    }, 700);
  }

  return (
    <div className={`view${active ? ' active' : ''}`} id="view-chat">
      <div className="chat-layout">
        <div className="chat-col">
          <div className="chat-scroll" ref={scrollRef}>
            {messages.map((m) => (
              <div key={m.id} className={`msg ${m.role}`}>
                {m.role === 'agent' && (
                  <div className="agent-avatar"><div className="ring"><i></i></div> AQUANEXUS AGENT</div>
                )}
                {m.chips && (
                  <div className="module-chips">
                    {m.chips.map((c) => <span key={c.label} className={`tag ${c.color}`}>{c.label}</span>)}
                  </div>
                )}
                <div className="bubble">{m.text}</div>
                {m.meta && <div className="msg-meta">{m.meta}</div>}
                {m.chart === 'chatMiniChart' && <ChatMiniChart />}
                {m.riskCard && <RiskCard />}
              </div>
            ))}
          </div>

          <div className="suggest-row">
            {SUGGESTIONS.map((s) => (
              <button key={s} className="chip-btn" onClick={() => sendMsg(s)}>{s}</button>
            ))}
          </div>
          <div className="chat-input">
            <input
              type="text"
              placeholder="Ask about ocean conditions, floats, spills, minerals, or cables…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') sendMsg(input.trim()); }}
            />
            <button className="send-btn" onClick={() => sendMsg(input.trim())}>
              <svg viewBox="0 0 24 24"><path d="M2 12l19-9-9 19-2-8-8-2z" /></svg>
            </button>
          </div>
        </div>

        <div className="side-col">
          <div className="panel">
            <div className="panel-head"><h3>Session Context</h3><span className="tag mute">LIVE</span></div>
            <div style={{ padding: '12px 16px' }}>
              <div className="mini-stat"><span className="k">Region</span><span className="v">Arabian Sea</span></div>
              <div className="mini-stat"><span className="k">Active floats</span><span className="v">214</span></div>
              <div className="mini-stat"><span className="k">Modules engaged</span><span className="v">ARGO, CABLES</span></div>
              <div className="mini-stat"><span className="k">Last sync</span><span className="v">2 min ago</span></div>
            </div>
          </div>
          <div className="panel" style={{ flex: 1 }}>
            <div className="panel-head"><h3>Reasoning Snapshot</h3></div>
            <div className="trail-mini">
              <div className="trail-step done"><span className="idx">1</span><span className="t">Parsed query → region + threat intent</span></div>
              <div className="trail-step done"><span className="idx">2</span><span className="t">Routed to ARGO + Cables modules</span></div>
              <div className="trail-step done"><span className="idx">3</span><span className="t">Pulled float 2903421 last 4 cycles</span></div>
              <div className="trail-step done"><span className="idx">4</span><span className="t">Cross-referenced cable corridor geometry</span></div>
              <div className="trail-step"><span className="idx">5</span><span className="t">Awaiting next query…</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
