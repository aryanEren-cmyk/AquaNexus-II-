import { useEffect, useState } from 'react';

export default function TopBar() {
  const [depth, setDepth] = useState('1,847 m');

  useEffect(() => {
    const id = setInterval(() => {
      const base = 1847 + Math.round((Math.random() - 0.5) * 14);
      setDepth(base.toLocaleString() + ' m');
    }, 2600);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="topbar">
      <div className="brand">
        <svg className="brand-mark" viewBox="0 0 40 40" fill="none">
          <path d="M4 26 Q10 20 16 26 T28 26 T40 26" stroke="#2dd4bf" strokeWidth="2" fill="none" opacity="0.9" />
          <path d="M4 32 Q10 26 16 32 T28 32 T40 32" stroke="#1a8f82" strokeWidth="2" fill="none" opacity="0.6" />
          <circle cx="20" cy="14" r="7" stroke="#e8f1f2" strokeWidth="1.6" fill="none" />
          <circle cx="20" cy="14" r="2" fill="#2dd4bf" />
        </svg>
        <div>
          <div className="brand-name">Aqua<span>Nexus</span></div>
          <div className="brand-sub">Ocean Intelligence Console</div>
        </div>
      </div>
      <div className="top-right">
        <div className="status-pill"><span className="dot pulse"></span> AGENT ONLINE</div>
        <div className="status-pill">
          <span className="dot" style={{ background: 'var(--gold)', boxShadow: '0 0 8px var(--gold)' }}></span>
          3,842 ARGO FLOATS TRACKED
        </div>
        <div className="sonar-wrap">
          <div className="sonar"></div>
          <div className="depth-read">MEAN DEPTH<br /><b>{depth}</b></div>
        </div>
      </div>
    </div>
  );
}
