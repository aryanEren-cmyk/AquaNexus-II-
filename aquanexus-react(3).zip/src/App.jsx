import { useState } from 'react';
import TopBar from './components/TopBar.jsx';
import NavRail from './components/NavRail.jsx';
import ChatView from './components/views/ChatView.jsx';
import DashboardView from './components/views/DashboardView.jsx';
import MapView from './components/views/MapView.jsx';
import ProfilesView from './components/views/ProfilesView.jsx';
import AlertsView from './components/views/AlertsView.jsx';
import TrailView from './components/views/TrailView.jsx';
import ResultsView from './components/views/ResultsView.jsx';

export default function App() {
  const [activeView, setActiveView] = useState('chat');

  function handleNavChange(view) {
    setActiveView(view);
  }

  return (
    <div className="app">
      <TopBar />
      <NavRail activeView={activeView} onChange={handleNavChange} />
      <div className="main">
        <ChatView active={activeView === 'chat'} />
        <DashboardView active={activeView === 'dashboard'} />
        <MapView active={activeView === 'map'} />
        <ProfilesView active={activeView === 'profiles'} />
        <AlertsView active={activeView === 'alerts'} />
        <TrailView active={activeView === 'trail'} />
        <ResultsView active={activeView === 'results'} />
      </div>
    </div>
  );
}
