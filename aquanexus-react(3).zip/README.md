# AquaNexus — React Frontend

React conversion of the AquaNexus Ocean Intelligence Console. Same UI, same structure, same behavior as the original static HTML build — just componentized.

## Run it

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

Output goes to `dist/`.

## Structure

```
src/
  App.jsx                 → shell: top bar + nav rail + view switcher
  components/
    TopBar.jsx             → brand, status pills, sonar, live depth ticker
    NavRail.jsx             → left nav (Chat / Charts / Map / Profile / Alerts / Trail / Data)
    views/
      ChatView.jsx          → conversational interface, inline mini chart, risk card
      DashboardView.jsx     → 4 Chart.js charts (SST trend, module share, salinity, anomalies)
      MapView.jsx           → Leaflet map, toggleable layers (ARGO/spill/mineral/cable)
      ProfilesView.jsx      → float list + temp/salinity depth profiles
      AlertsView.jsx        → severity-coded alert cards
      TrailView.jsx         → step-by-step agent reasoning trail
      ResultsView.jsx       → filterable structured results table
  data/
    oceanData.js            → all the static demo data in one place — swap for real API calls here
  utils/
    chartHelpers.js         → shared Chart.js defaults + gradient helper
  styles.css                → all original CSS, unchanged
```

## Wiring up the real backend

Every view currently renders from static data (`src/data/oceanData.js`) or local component state
(chat messages in `ChatView.jsx`). Once the backend/agent API is ready, replace those static
sources with real fetch/query calls — component structure and styling don't need to change.
